# Project-1-introductions
This repository contain slides pack and Jupyter Notebook for Project-1  World Airbnb Hawaii.
There is only one jupiter notebook that can run beginning to end.
Will need a google API to pull map in.
